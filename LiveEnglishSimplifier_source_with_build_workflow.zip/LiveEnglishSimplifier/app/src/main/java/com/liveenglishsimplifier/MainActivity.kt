package com.liveenglishsimplifier

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Context
import android.util.TypedValue

class MainActivity : Activity() {
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var lastFinal = ""
    private lateinit var status: TextView
    private lateinit var original: TextView
    private lateinit var simple: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var level: Spinner
    private val history = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(245,247,246)
        window.navigationBarColor = Color.rgb(245,247,246)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        buildUi()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition is not available on this phone. Install/enable Google speech services."
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.rgb(245,247,246))
        }
        val title = TextView(this).apply {
            text = "Live Easy English"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(24,44,39))
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "Play CNN or another video near your phone. The microphone listens and shows easier English."
            setTextSize(15f); setTextColor(Color.rgb(75,88,83)); setPadding(0, dp(6), 0, dp(12))
        })
        status = TextView(this).apply { text = "Ready to listen"; setTextSize(14f); setTextColor(Color.rgb(23,107,87)); setPadding(0, dp(4), 0, dp(10)) }
        root.addView(status)
        level = Spinner(this)
        level.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("A2 - Easier English", "B1 - Intermediate English"))
        root.addView(level)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) }
        startButton = Button(this).apply { text = "Start listening"; setOnClickListener { startListening() } }
        stopButton = Button(this).apply { text = "Stop"; isEnabled = false; setOnClickListener { stopListening() } }
        buttons.addView(startButton, LinearLayout.LayoutParams(0, dp(52), 1f))
        buttons.addView(stopButton, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(buttons)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        original = TextView(this).apply { setTextSize(17f); setTextColor(Color.rgb(30,43,39)); text = "Your live transcript will appear here…"; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        simple = TextView(this).apply { setTextSize(17f); setTextColor(Color.rgb(23,107,87)); text = "Simpler English will appear here…"; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        content.addView(section("ORIGINAL ENGLISH", original))
        content.addView(section("SIMPLER ENGLISH · 3–4 WORD CHUNKS", simple))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(TextView(this).apply { text = "Prototype: simplification uses built-in word substitutions, not a full AI model. Accuracy depends on your phone's speech recognition."; setTextSize(12f); setTextColor(Color.GRAY); setPadding(0, dp(10), 0, 0) })
        setContentView(root)
    }

    private fun section(label: String, body: TextView): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); background = rounded(Color.WHITE); setMarginsCompat(dp(0), dp(6), dp(0), dp(8)) }
        box.addView(TextView(this).apply { text = label; setTextSize(12f); setTypeface(null, Typeface.BOLD); setTextColor(Color.rgb(95,108,102)); setPadding(0, 0, 0, dp(8)) })
        box.addView(body)
        return box
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.text = "Speech recognition is unavailable."; return }
        listening = true
        startButton.isEnabled = false; stopButton.isEnabled = true
        status.text = "Listening… keep the video sound near the phone microphone."
        beginRecognition()
    }

    private fun beginRecognition() {
        if (!listening) return
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { runOnUiThread { status.text = "Listening…" } }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { if (listening) restartSoon() }
                override fun onError(error: Int) { if (listening) restartSoon() }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) addFinal(text)
                    if (listening) restartSoon()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) runOnUiThread {
                        val preview = if (history.isNotEmpty()) history.toString() + " " + text else text
                        original.text = preview
                        simple.text = simplifyAndChunk(preview)
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) { restartSoon() }
    }

    private fun addFinal(text: String) {
        val clean = text.trim()
        if (clean.isNotEmpty() && clean != lastFinal) {
            if (history.isNotEmpty()) history.append(" ")
            history.append(clean)
            lastFinal = clean
            runOnUiThread {
                original.text = history.toString()
                simple.text = simplifyAndChunk(history.toString())
            }
        }
    }

    private fun simplifyAndChunk(text: String): String {
        val levelB1 = level.selectedItemPosition == 1
        val replacements = if (levelB1) mapOf(
            "approving" to "allowing", "major" to "large", "controversial" to "causing disagreement",
            "criticism" to "negative comments", "environmental" to "about nature", "campaign groups" to "active groups",
            "supply" to "provide", "development" to "project", "purchase" to "buy", "approximately" to "about",
            "commence" to "start", "terminate" to "end", "individuals" to "people", "demonstrate" to "show",
            "assistance" to "help", "require" to "need", "numerous" to "many", "reside" to "live"
        ) else mapOf(
            "approving" to "saying yes to", "major" to "big", "controversial" to "causing arguments",
            "criticism" to "saying bad things about", "environmental" to "about nature", "campaign groups" to "groups",
            "supply" to "give", "development" to "project", "approximately" to "about", "commence" to "start",
            "terminate" to "end", "individuals" to "people", "demonstrate" to "show", "assistance" to "help",
            "require" to "need", "numerous" to "many", "reside" to "live"
        )
        var out = text
        for ((from, to) in replacements) out = out.replace(Regex("\\b${Regex.escape(from)}\\b", RegexOption.IGNORE_CASE), to)
        val words = out.split(Regex("\\s+")).filter { it.isNotBlank() }
        val chunks = words.chunked(4).map { it.joinToString(" ") }
        return chunks.joinToString("\n\n")
    }

    private fun restartSoon() {
        android.os.Handler(mainLooper).postDelayed({ if (listening) beginRecognition() }, 350)
    }

    private fun stopListening() {
        listening = false
        try { recognizer?.stopListening(); recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        startButton.isEnabled = true; stopButton.isEnabled = false
        status.text = "Stopped"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startListening()
        else status.text = "Microphone permission is required."
    }

    override fun onDestroy() { stopListening(); super.onDestroy() }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }
    private fun LinearLayout.setMarginsCompat(l: Int, t: Int, r: Int, b: Int) { (layoutParams as? LinearLayout.LayoutParams)?.setMargins(l,t,r,b) }
}
