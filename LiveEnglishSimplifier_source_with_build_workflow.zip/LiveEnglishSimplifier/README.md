# Live Easy English (Android source project)

This is a prototype Android app source project. It listens to nearby English audio through the phone microphone, uses Android speech recognition for transcription, and displays the recognized words in groups of four with simple built-in word substitutions.

## Important limitations
- This is not a compiled APK. The current build environment does not include the Android SDK/Gradle installation needed to build and verify an APK.
- The simplification is a small offline-style substitution dictionary, not an AI paraphraser. It will not reliably simplify every sentence or preserve meaning in all cases.
- Speech recognition quality depends on the phone and its speech services. Keep the video audio audible near the phone microphone. This app does not directly capture audio from another app.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`LiveEnglishSimplifier`) in Android Studio.
3. Let Gradle sync and install the Android SDK platform 35 if prompted.
4. Connect an Android phone or choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Grant microphone permission when you open the app.

Package: `com.liveenglishsimplifier`
